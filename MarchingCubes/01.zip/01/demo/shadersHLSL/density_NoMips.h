#define EVAL_NO_MIPS
#include "density.h"